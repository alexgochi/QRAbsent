<?php
//This script is designed by Android-Examples.com
//Define your host here.
$servername = "localhost";
//Define your database username here.
$username = "bebas";
//Define your database password here.
$password = "root";
//Define your database name here.
$dbname = "qr_absent";
?>