<?php

define("DB_HOST", "localhost");
define("DB_USER", "bebas");
define("DB_PASSWORD", "root");
define("DB_DATABASE", "qr_absent");
?>
